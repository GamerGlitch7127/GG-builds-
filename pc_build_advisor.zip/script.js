document.getElementById("pc-form").addEventListener("submit", function(event) {
    event.preventDefault();
    const budget = document.getElementById("budget").value;
    const purpose = document.getElementById("purpose").value;
    let cpu = "Intel i5 12400F", gpu = "RTX 3060";

    if (budget >= 1000) {
        cpu = purpose === "gaming" ? "Ryzen 7 7800X3D" : "Intel i7 13700K";
        gpu = "RTX 4070";
    } else if (budget >= 700) {
        cpu = purpose === "gaming" ? "Ryzen 5 7600" : "Intel i5 13600K";
        gpu = "RTX 4060 Ti";
    }

    document.getElementById("results").innerHTML = `<h3>Recommended Build:</h3>
    <p><strong>CPU:</strong> ${cpu}</p>
    <p><strong>GPU:</strong> ${gpu}</p>`;
});